package com.example.serviceexample;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button buttonStart, buttonStop,buttonNext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




            buttonStart = findViewById(R.id.btnStartService);
            buttonStop = findViewById(R.id.btnStopService);
            buttonNext =  findViewById(R.id.btnNextPage);

            buttonStart.setOnClickListener( this);
            buttonStop.setOnClickListener( this);
            buttonNext.setOnClickListener(this);


        }
        public void onClick(View src) {
            switch (src.getId()) {
                case R.id.btnStartService:

                    startService(new Intent(this, MyService.class));
                    break;
                case R.id.btnStopService:
                    stopService(new Intent(this, MyService.class));
                    break;
                case R.id.btnNextPage:
                    Intent intent=new Intent(this,NextPage.class);
                    startActivity(intent);
                    break;
            }
        }
}

